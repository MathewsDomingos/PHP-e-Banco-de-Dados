Updated for phpMyAdmin 5.0+

## Install

Put the theme folder to your phpMyAdmin/themes folder
### XAMPP in Windows
\xampp\phpMyAdmin\themes
### MAMPP in MacOS
/Applications/MAMP/bin/phpMyAdmin

Open phpMyAdmin dashboard and change theme to **pmahomme_dark** at *Appearance settings*
